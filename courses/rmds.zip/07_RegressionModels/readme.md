## Regression module

This is the readme file for the regression component of the set of data science modules

* [Introduction](01_01_introduction/index.thml)
* [Notation](01_02_notation/index.html)
* [Least squares](01_03_ols/index.html)
* [Regression to mediocrity](01_04_rttm/index.html)
* [Linear Regression](01_05_linearRegression/index.html)
* [Residual Variation](01_06_residualVariation/index.html)





