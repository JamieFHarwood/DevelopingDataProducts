## Grading and logistics

The grading in this class is very straightforward. 

1. There are four quizzes, each containing in the neighborhood of 10 questions.
2. Each question is equally weighted as 1 point.
3. Some require two answers, each giving half of a point (for a maximum total of 1 point for those questions).
4. Your total points is the sum of the points questions across all quizzes that you answered correctly (using all of your quiz attempts).
5. 70% or more of the total points is a pass for the class. 
6. 80% or more of the total points is a pass with distinction.







